﻿using System;

namespace FunctionLibrary
{
    public class FunctionCalculator
    {
        public double CalculateFunction(double x, double N)
        {
            try
            {
                if (x == N)
                {
                    throw new ArgumentException("Division by zero.");
                }

                return 1 / (x - N);
            }
            catch (DivideByZeroException ex)
            {
                throw new DivideByZeroException("Division by zero.", ex);
            }
            catch (OverflowException ex)
            {
                throw new OverflowException("Out of range.", ex);
            }
        }
    }
}
