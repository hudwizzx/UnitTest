using Microsoft.VisualStudio.TestTools.UnitTesting;
using FunctionLibrary;

namespace FunctionLibraryTests
{
    [TestClass]
    public class FunctionCalculatorTests
    {
        [TestMethod]
        public void TestNormalCase()
        {
            FunctionCalculator calculator = new FunctionCalculator();
            double result = calculator.CalculateFunction(2.0, 1.0);

            Assert.AreEqual(1.0, result);
        }

        [TestMethod]
        public void TestDivisionByZero()
        {
            FunctionCalculator calculator = new FunctionCalculator();

            Assert.ThrowsException<DivideByZeroException>(() => calculator.CalculateFunction(1.0, 1.0));
        }

        [TestMethod]
        public void TestOutOfRange()
        {
            FunctionCalculator calculator = new FunctionCalculator();

            Assert.ThrowsException<OverflowException>(() => calculator.CalculateFunction(1.0, 1.0));
        }
    }
}
